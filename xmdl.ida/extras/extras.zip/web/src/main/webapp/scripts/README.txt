The majority of files in this directory come from Prototype
and Scriptaculous - two JavaScript libraries that make Ajax
easier.

http://prototypejs.org (version 1.5.0)
http://script.aculo.us (version 1.6.5)

The Prototype framework consists of a single file: prototype.js.

The Script.aculo.us framework consists of six files:

builder.js
controls.js
dragdrop.js
effects.js
scriptaculous.js
slider.js

By including scriptaculous.js in your pages, all the rest of
the files are included as well.

----------------

For good documentation about Prototype, see its website at:

http://prototypejs.org/learn

Other good resources include:

http://particletree.com/features/quick-guide-to-prototype

...and...

http://www.sergiopereira.com/articles/prototype.js.html

----------------

The best scriptaculous documentation is at:

http://wiki.script.aculo.us/scriptaculous/show/HomePage

